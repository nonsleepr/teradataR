is.td.expression <- function(x) {
    inherits(x, "td.expression")
}
 
