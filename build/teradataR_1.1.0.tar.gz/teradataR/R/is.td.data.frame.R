is.td.data.frame <- function(x) {
    inherits(x, "td.data.frame")
}
 
