teradataR
=========

R package to perform in-database analytics using Teradata database.

Compatible with both R version 2 and 3.

Prebuilt package could be found [here](https://github.com/Teradata/teradataR/raw/master/build/teradataR_1.1.0.tar.gz).

## Dependencies

+ RJDBC
 + rJava
+ RODBC

## Installation

To install the package, issue the following command from R REPL:

    install.packages("C:\\Documents and Settings\\User\\My Documents\\Downloads\\teradataR_1.1.0.tar.gz", repos=NULL,type="source");

Where first argument is the path to the package file.

