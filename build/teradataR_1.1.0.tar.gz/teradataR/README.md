teradataR
=========

R package to perform in-database analytics using Teradata database.

Compatible with both R version 2 and 3.
